import{cr as r}from"./app-DmW52sVY.js";var e=r();export{e as O};
