const s="/build/assets/hero_images-BLqt6Etg.png",t="/build/assets/qr-Dj5-iWPt.png",a="/build/assets/elephants-Ctp6NwdZ.png";export{s as _,t as a,a as b};
